run ImageStitching.exe with image directory set5/
it will output panorama.jpg